<?php
/**
 * @package     Tyliai
 * @subpackage  Content Reactor
 * @link        http://www.tyliai.eu
 * @author      edast
 * @license		GNU/GPL
 * @
 */

// no direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

// Include the syndicate functions only once
require_once( dirname(__FILE__).DS.'helper.php' );


global $mainframe;

$db 	  =& JFactory::getDBO();
$document =& JFactory::getDocument();
$pathway  =& $mainframe->getPathway();

$document =& JFactory::getDocument();
$document->addScript(JURI::base().'/components/com_contentreactor/js/jquery-1.3.1.min.js');
$document->addScript(JURI::base().'/components/com_contentreactor/js/jquery-ui-min.js');
$document->addScript(JURI::base().'/components/com_contentreactor/js/jquery.cycle.all.min.js');
$document->addScript(JURI::base().'/components/com_contentreactor/js/jquery.easing.js');
$document->addScript(JURI::base().'/components/com_contentreactor/js/jquery.easing.compatibility.js');
$document->addScript(JURI::base().'/components/com_contentreactor/js/jquery.timers.js');
$document->addScript(JURI::base().'/components/com_contentreactor/js/tyliai.cycle.effects.js');


$projector_id   = $params->get( 'id', 0 );
$projector = modContentreactorHelper::getSlider($projector_id);
$slides = modContentreactorHelper::getSlides($projector_id);

$document->addStyleSheet(JURI::base().'/components/com_contentreactor/css/style.css');
$document->addStyleDeclaration("#tyliai_cr_visual{width:".$projector->pic_width."px;height:".$projector->pic_height."px;}
    #tyliai_cr_visual div {width: ".$projector->pic_width."px;height: ".$projector->pic_height."px;}
    #info{width:".$projector->width."px;height: ".($projector->height - $projector->pic_height)."px;}
    .info_inner {height:".($projector->height - $projector->pic_height)."px;width: ".$projector->width."px;}", "text/css");

//$css_str = file_get_contents(JPATH_SITE.DS.'components'.DS.'com_contentreactor'.DS.'css'.DS.'style.css');
//$css_str = str_replace('{PIC_WIDTH}', $projector->pic_width, $css_str);
//$css_str = str_replace('{PIC_HEIGHT}', $projector->pic_height, $css_str);
//$css_str = str_replace('{INFO_WIDTH}', $projector->width, $css_str);
//$css_str = str_replace('{INFO_HEIGHT}', ($projector->height - $projector->pic_height), $css_str);
//
//$document->addStyleDeclaration($css_str, "text/css");

require( JModuleHelper::getLayoutPath( 'mod_contentreactor' ) );

