<?php
/**
 * @package     Tyliai
 * @subpackage  Content Reactor
 * @link        http://www.tyliai.eu
 * @author      edast
 * @license		GNU/GPL
 * @
 */

class modContentreactorHelper
{
    function getSlider( $id )
    {
		$db	=& JFactory::getDBO();

		$query = 'SELECT *' .
			' FROM #__contentreactor_projectors' .
			' WHERE id = ' . (int) $id .
			' ';
		$db->setQuery($query);

		if (!($slider = $db->loadObject())) {
			echo "MD ".$db->stderr();
			return;
		}

		return $slider;
    }

	function getSlides($slider_id)
	{
		$db	=& JFactory::getDBO();

        $query = "SELECT * from #__contentreactor_slides WHERE projector_id = ".$slider_id. " AND  `published` =1 ORDER BY `order`, `id` ";
		$db->setQuery($query);

		if (!($options = $db->loadObjectList())) {
			echo "MD ".$db->stderr();
			return;
		}

		return $options;
	}
}
