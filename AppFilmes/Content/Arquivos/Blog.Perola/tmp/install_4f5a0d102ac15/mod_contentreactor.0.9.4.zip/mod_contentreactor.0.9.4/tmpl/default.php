<?php
/**
 * @package     Tyliai
 * @subpackage  Content Reactor
 * @link        http://www.tyliai.eu
 * @author      edast
 * @license		GNU/GPL
 * @
 */
defined('_JEXEC') or die('Restricted access');
if (!empty($slides)) {
?>

<script type="text/javascript">
    jQuery.noConflict();
    var inner = "#info_inner_" + <?php echo $slides[0]->id; ?>;
    var slider_timeout = <?php echo $projector->slide_interval; ?>;
    (function($) {
        $(document).ready(function () {
            $('#tyliai_cr_visual').cycle( {
                fx: '<?php echo $projector->pic_effect;?>',
                easeOut: '<?php echo $projector->pic_ease_out;?>',
                easeIn: '<?php echo $projector->pic_ease_out;?>',
                sync: 1,
                'timeout': 0
            });
            $('#info').cycle({
                fx: '<?php echo $projector->info_effect;?>',
                'timeout': 0,
                cleartype:  1,
                easeOut: '<?php echo $projector->info_ease_out;?>',
                easeIn: '<?php echo $projector->info_ease_out;?>'
            });
            $(document).everyTime(slider_timeout, function(i) {
                $('#tyliai_cr_visual').cycle('resume', true);
                $('#info').cycle('resume', true);
            });
        })


    })(jQuery);

</script>


<div id="tyliai_cr">
    <div id="tyliai_cr_visual" class="pics">
        <?php

        foreach ($slides as $slide) {
            ?>
        <div id="tyliai_cr_visual_<?php echo $slide->id; ?>" style="background:url(<?php echo $slide->picture;?>) no-repeat center center;">
        </div>
        <?php } ?>
    </div>
    <div id="info" class="clear">
        <?php
        foreach ($slides as $slide) {
            ?>
        <div id="<?php echo "info_inner_".$slide->id; ?>" class="info_inner">
            <?php echo $slide->info; ?>
        </div>
        <?php } ?>
    </div>
</div>
<?php
} else {
    ?>
    <h3 style="color:red; font-weight:bold;"><?php echo JText::_( 'Error! No projector was selected in Content Reactor module config' ); ?></h3>
<?php
}
?>



