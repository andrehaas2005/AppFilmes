<?php
/**
 * @package     Tyliai
 * @subpackage  Content Reactor
 * @link        http://www.tyliai.eu
 * @author      edast
 * @license		GNU/GPL
 * @
 */
defined('_JEXEC') or die('Restricted access'); ?>

<form action="index.php" method="post" name="adminForm" id="adminForm">
    <div class="col width-50">
        <fieldset class="adminform">
            <legend><?php echo JText::_( 'Details' ); ?></legend>

            <table class="admintable">
                <tr>
                    <td width="100" align="right" class="key">
                        <label for="Name">
                            <?php echo JText::_( 'Name' ); ?>:
                        </label>
                    </td>
                    <td>
                        <input class="text_area" type="text" name="name" id="name" size="32" maxlength="250" value="<?php echo $this->projector->name;?>" />
                    </td>
                </tr>
                <tr>
                    <td width="100" align="right" class="key">
                        <label for="width">
                            <?php echo JText::_( 'Width' ); ?>:
                        </label>
                    </td>
                    <td>
                        <input class="text_area" type="text" name="width" id="width" size="32" maxlength="250" value="<?php echo $this->projector->width;?>" />
                    </td>
                    <td>
                        <label for="width">
                            <?php echo JText::_( 'px' ); ?>
                        </label>
                    </td>
                </tr>
                <tr>
                    <td width="100" align="right" class="key">
                        <label for="height">
                            <?php echo JText::_( 'Height' ); ?>:
                        </label>
                    </td>
                    <td>
                        <input class="text_area" type="text" name="height" id="height" size="32" maxlength="250" value="<?php echo $this->projector->height;?>" />
                     </td>
                    <td>
                       <label for="height">
                            <?php echo JText::_( 'px' ); ?>
                        </label>
                    </td>
                </tr>
                <tr>
                    <td width="100" align="right" class="key">
                        <label for="pic_width">
                            <?php echo JText::_( 'Image width' ); ?>:
                        </label>
                    </td>
                    <td>
                        <input class="text_area" type="text" name="pic_width" id="pic_width" size="32" maxlength="250" value="<?php echo $this->projector->pic_width;?>" />
                    </td>
                    <td>
                        <label for="pic_width">
                            <?php echo JText::_( 'px' ); ?>
                        </label>
                    </td>
                </tr>
                <tr>
                    <td width="100" align="right" class="key">
                        <label for="pic_height">
                            <?php echo JText::_( 'Image height' ); ?>:
                        </label>
                    </td>
                    <td>
                        <input class="text_area" type="text" name="pic_height" id="pic_height" size="32" maxlength="250" value="<?php echo $this->projector->pic_height;?>" />
                    </td>
                    <td>
                        <label for="pic_height">
                            <?php echo JText::_( 'px' ); ?>
                        </label>
                    </td>
                </tr>
                <tr>
                    <td width="100" align="right" class="key">
                        <label for="slide_interval">
                            <?php echo JText::_( 'Slide change delay ' ); ?>:
                        </label>
                    </td>
                    <td>
                        <input class="text_area" type="text" name="slide_interval" id="slide_interval" size="32" maxlength="250" value="<?php echo $this->projector->slide_interval;?>" />
                    </td>
                    <td>
                        <label for="slide_interval">
                            <?php echo JText::_( 'ms' ); ?>
                        </label>
                    </td>
                </tr>
            </table>
        </fieldset>
    </div>
    <div class="col width-50">
        <fieldset class="adminform">
            <legend><?php echo JText::_( 'Effects' ); ?></legend>

            <table class="admintable">
                <tr>
                    <td width="100" align="right" class="key">
                        <label for="pic_effect">
                            <?php echo JText::_( 'Image effect' ); ?>:
                        </label>
                    </td>
                    <td>
                        <?php  echo JHTML::_('select.genericlist',   $this->eff_list, 'pic_effect', 'class="text_area" size="1"', 'value', 'text', $this->projector->pic_effect);?>
                    </td>
                </tr>
                <tr>
                    <td width="100" align="right" class="key">
                        <label for="info_effect">
                            <?php echo JText::_( 'Text area effect' ); ?>:
                        </label>
                    </td>
                    <td>
                        <?php  echo JHTML::_('select.genericlist',   $this->eff_list, 'info_effect', 'class="info_area" size="1"', 'value', 'text', $this->projector->info_effect);?>
                    </td>
                </tr>
                <tr>
                    <td width="100" align="right" class="key">
                        <label for="pic_ease_in">
                            <?php echo JText::_( 'Image easeIn effect' ); ?>:
                        </label>
                    </td>
                    <td>
                        <?php  echo JHTML::_('select.genericlist',   $this->easing_list, 'pic_ease_in', 'class="text_area" size="1"', 'value', 'text', $this->projector->pic_ease_in);?>
                    </td>
                </tr>
                <tr>
                    <td width="100" align="right" class="key">
                        <label for="pic_ease_out">
                            <?php echo JText::_( 'Image easeOut effect' ); ?>:
                        </label>
                    </td>
                    <td>
                        <?php  echo JHTML::_('select.genericlist',   $this->easing_list, 'pic_ease_out', 'class="text_area" size="1"', 'value', 'text', $this->projector->pic_ease_out);?>
                    </td>
                </tr>
                <tr>
                    <td width="100" align="right" class="key">
                        <label for="info_ease_in">
                            <?php echo JText::_( 'Text area easeIn effect' ); ?>:
                        </label>
                    </td>
                    <td>
                        <?php  echo JHTML::_('select.genericlist',   $this->easing_list, 'info_ease_in', 'class="text_area" size="1"', 'value', 'text', $this->projector->info_ease_in);?>
                    </td>
                </tr>
                <tr>
                    <td width="100" align="right" class="key">
                        <label for="info_ease_out">
                            <?php echo JText::_( 'Text area easeOut effect' ); ?>:
                        </label>
                    </td>
                    <td>
                        <?php  echo JHTML::_('select.genericlist',   $this->easing_list, 'info_ease_out', 'class="text_area" size="1"', 'value', 'text', $this->projector->info_ease_out);?>
                    </td>
                </tr>
            </table>
        </fieldset>
    </div>
     <div class="clr"></div>
    <div class="col100">
        <fieldset class="adminlist">
            <legend><?php echo JText::_( 'Slide list' ); ?></legend>

            <table class="adminlist">
            <thead>
                <tr>
                    <th width="5">
                        <?php echo JText::_( 'ID' ); ?>
                    </th>
                    <th width="20">
                        <input type="checkbox" name="toggle" value="" onclick="checkAll(<?php echo count( $this->slides ); ?>);" />
                    </th>
                    <th>
                        <?php echo JText::_( 'Name' ); ?>
                    </th>
                    <th>
                        <?php echo JText::_( 'Order' ); ?>
                    </th>
                    <th>
                        <?php echo JText::_( 'Published' ); ?>
                    </th>
                    <th>
                        <?php echo JText::_( 'Image' ); ?>
                    </th>
                </tr>
            </thead>
	<?php
	$k = 0;
	for ($i=0, $n=count( $this->slides ); $i < $n; $i++)
	{
		$row = &$this->slides[$i];

		$link 		= JRoute::_( 'index.php?option=com_contentreactor&controller=slide&task=edit&cid[]='. $row->id );

        $checked 	= JHTML::_('grid.checkedout',   $row, $i );
//		$checked 	= JHTML::_('grid.id',   $row, $i );
		$published 	= JHTML::_('grid.published', $row, $i );
	?>
		<tr class="<?php echo "row$k"; ?>">
			<td>
				<?php echo $row->id ?>
			</td>
			<td>
				<?php echo $checked; ?>
			</td>
			<td>
               <a href="<?php echo $link  ?>">
					<?php echo $row->name; ?></a>
			</td>
			<td align="center">
				<?php echo $row->order; ?>
			</td>
			<td align="center">
				<?php echo $published;?>
			</td>
			<td align="center">
                <a class="lightbox" href="<?php echo $row->picture; ?>" title="<?php echo $row->name; ?>"><?php echo $row->picture; ?></a>
			</td>
		</tr>
		<?php
			$k = 1 - $k;
		}
		?>
            </table>
        </fieldset>
    </div>
    <div class="clr"></div>

    <input type="hidden" name="option" value="com_contentreactor" />
	<input type="hidden" name="boxchecked" value="0" />
	<input type="hidden" name="filter_order" value="<?php echo $this->lists['order']; ?>" />
	<input type="hidden" name="filter_order_Dir" value="<?php echo $this->lists['order_Dir']; ?>" />
    <input type="hidden" name="id" value="<?php echo $this->projector->id; ?>" />
    <input type="hidden" name="task" value="" />
    <input type="hidden" name="controller" value="projector" />
    <?php echo JHTML::_( 'form.token' ); ?>
</form>
