<?php
/**
 * @package     Tyliai
 * @subpackage  Content Reactor
 * @link        http://www.tyliai.eu
 * @author      edast
 * @license		GNU/GPL
 * @
 */
defined('_JEXEC') or die('Restricted access'); ?>

<form action="index.php" method="post" name="adminForm">
    <div id="editcell">
        <table class="adminlist">
            <thead>
                <tr>
                    <th width="5">
                        <?php echo JText::_( 'ID' ); ?>
                    </th>
                    <th width="20">
                        <input type="checkbox" name="toggle" value="" onclick="checkAll(<?php echo count( $this->items ); ?>);" />
                    </th>
                    <th>
                        <?php echo JText::_( 'Name' ); ?>
                    </th>
                    <th>
                        <?php echo JText::_( 'Width' ); ?>
                    </th>
                    <th>
                        <?php echo JText::_( 'Height' ); ?>
                    </th>
                    <th>
                        <?php echo JText::_( 'Image width' ); ?>
                    </th>
                    <th>
                        <?php echo JText::_( 'Image height' ); ?>
                    </th>
                    <th>
                        <?php echo JText::_( 'Image effect' ); ?>
                    </th>
                    <th>
                        <?php echo JText::_( 'Text area effect' ); ?>
                    </th>
                    <th>
                        <?php echo JText::_( 'Slide change delay' ); ?>
                    </th>
                    <th>
                        <?php echo JText::_( '' ); ?>
                    </th>
                </tr>
            </thead>
            <?php
            $script_str = "
            var GB_ANIMATION = false;
            (function($) {
            $(document).ready(function () {
            ";
            $k = 0;
            for ($i=0, $n=count( $this->items ); $i < $n; $i++)	{
                $row = &$this->items[$i];
                $checked 	= JHTML::_('grid.id',   $i, $row->id );
                $link 		= JRoute::_( 'index.php?option=com_contentreactor&controller=projector&task=edit&cid[]='. $row->id );

                $script_str .= "$(\"#greybox_".$row->id."\").click(function(){\n
                                                  var t = this.title || this.innerHTML || this.href;\n
                                                  GB_show(t,this.href, ".($row->height + 80).", ".($row->width + 30).");\n
                                                  return false;\n
                                                });\n";

                ?>


            <tr class="<?php echo "row$k"; ?>">
                <td>
                    <?php echo $row->id; ?>
                </td>
                <td>
                    <?php echo $checked; ?>
                </td>
                <td>
                    <a href="<?php echo $link; ?>"><?php echo $row->name; ?></a>
                </td>
                <td>
                    <?php echo $row->width;?>
                </td>
                <td>
                    <?php echo $row->height;?>
                </td>
                <td>
                    <?php echo $row->pic_width;?>
                </td>
                <td>
                    <?php echo $row->pic_height;?>
                </td>
                <td>
                    <?php echo $row->pic_effect;?>
                </td>
                <td>
                    <?php echo $row->info_effect;?>
                </td>
                <td>
                    <?php echo $row->slide_interval; ?>
                </td>
                <td>
                    <a href="<?php echo JURI::root()?>/index.php?option=com_contentreactor&id=<?php echo $row->id?>&tmpl=component" title="<?php echo JText::_('preview');?>" id="greybox_<?php echo $row->id; ?>"><?php echo JText::_('preview');?></a>
                </td>
            </tr>
            <?php
            $k = 1 - $k;
        }
        $script_str .= "}) })(jQuery);";
        JFactory::getDocument()->addScriptDeclaration($script_str);
        ?>
        </table>
    </div>

    <input type="hidden" name="option" value="com_contentreactor" />
    <input type="hidden" name="task" value="" />
    <input type="hidden" name="boxchecked" value="0" />
    <input type="hidden" name="controller" value="projector" />
    <?php echo JHTML::_( 'form.token' ); ?>
</form>
