<?php
/**
 * @package     Tyliai
 * @subpackage  Content Reactor
 * @link        http://www.tyliai.eu
 * @author      edast
 * @license		GNU/GPL
 * @
 */

// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

class TableSlide extends JTable
{
	/**
	 * Primary Key
	 *
	 * @var int
	 */
	var $id = null;

	/**
	 * @var string
	 */
	var $name = null;

	/**
	 * @var boolean
	 */
	var $published = 1;

	/**
	 * @var string
	 */
	var $picture = null;
	/**
	 * @var string
	 */
	var $info = null;
	/**
	 * @var string
	 */
	var $pic_css = null;
	/**
	 * @var string
	 */
	var $info_css = null;
	/**
	 * @var string
	 */
	var $pic_effect = null;
	/**
	 * @var string
	 */
	var $info_effect = null;
	/**
	 * @var string
	 */
	var $info_ease_in = null;
	/**
	 * @var string
	 */
	var $info_ease_out = null;
	/**
	 * @var string
	 */
	var $pic_ease_in = null;
	/**
	 * @var string
	 */
	var $pic_ease_out = null;
	/**
	 * @var int
	 */
	var $interval = 1000;
	/**
	 * @var int
	 */
	var $projector_id = null;
	/**
	 * @var int
	 */
	var $order = null;


	/**
	 * Constructor
	 *
	 * @param object Database connector object
	 */
	function TableSlide(& $db) {
		parent::__construct('#__contentreactor_slides', 'id', $db);
	}
}