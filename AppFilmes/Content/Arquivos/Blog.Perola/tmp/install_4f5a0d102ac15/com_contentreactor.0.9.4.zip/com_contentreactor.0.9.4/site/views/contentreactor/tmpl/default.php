<?php
/**
 * @package     Tyliai
 * @subpackage  Content Reactor
 * @link        http://www.tyliai.eu
 * @author      edast
 * @license		GNU/GPL
 * @
 */
defined('_JEXEC') or die('Restricted access'); ?>

<script type="text/javascript">
    jQuery.noConflict();
    var inner = "#info_inner_" + <?php echo $this->slides[0]->id; ?>;
    //console.log("Init...");
    var projector_timeout = <?php echo $this->projector->slide_interval; ?>;
    (function($) {
        $(document).ready(function () {
            $('#tyliai_cr_visual').cycle( {
                fx: '<?php echo $this->projector->pic_effect;?>',
                sync: 1,
                easeOut: '<?php echo $this->projector->pic_ease_out;?>',
                easeIn: '<?php echo $this->projector->pic_ease_out;?>',
                speedIn: '<?php echo $this->projector->pic_speed_in;?>',
                speedOut: '<?php echo $this->projector->pic_speed_out;?>',
                'timeout': 0
            });
            $('#info').cycle({
                fx: '<?php echo $this->projector->info_effect;?>',
                'timeout': 0,
                cleartype:  1,
                easeOut: '<?php echo $this->projector->info_ease_out;?>',
                easeIn: '<?php echo $this->projector->info_ease_out;?>',
                speedIn: '<?php echo $this->projector->info_speed_in;?>',
                speedOut: '<?php echo $this->projector->info_speed_out;?>'
            });
            $(document).everyTime(projector_timeout, function(i) {
                $('#tyliai_cr_visual').cycle('resume', true);
                $('#info').cycle('resume', true); 
            });
        })


    })(jQuery);

</script>





<div id="tyliai_cr">
    <div id="tyliai_cr_visual" class="pics">
        <?php
        foreach ($this->slides as $slide) {
            ?>
        <div id="tyliai_cr_visual_<?php echo $slide->id; ?>" style="background:url(<?php echo $slide->picture;?>) no-repeat center center;">
        </div>
        <?php } ?>
    </div>
    <div id="info" class="clear">
        <?php
        foreach ($this->slides as $slide) {
            ?>
        <div id="<?php echo "info_inner_".$slide->id; ?>" class="info_inner">
            <?php echo $slide->info; ?>
        </div>
        <?php } ?>
    </div>
</div>


