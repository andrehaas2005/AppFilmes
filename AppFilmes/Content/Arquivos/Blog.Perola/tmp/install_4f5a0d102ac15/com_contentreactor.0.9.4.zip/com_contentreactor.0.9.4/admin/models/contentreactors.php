<?php
/**
 * @package     Tyliai
 * @subpackage  Content Reactor
 * @link        http://www.tyliai.eu
 * @author      edast
 * @license		GNU/GPL
 * @
 */

// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

jimport( 'joomla.application.component.model' );

class ContentreactorsModelContentreactors extends JModel
{
	/**
	 * Contentreactors data array
	 *
	 * @var array
	 */
	var $_data;


	/**
	 * Returns the query
	 * @return string The query to be used to retrieve the rows from the database
	 */
	function _buildQuery()
	{
		$query = ' SELECT * '
			. ' FROM #__contentreactor_projectors '
		;

		return $query;
	}

	function getData()
	{
		// Lets load the data if it doesn't already exist
		if (empty( $this->_data ))
		{
			$query = $this->_buildQuery();
			$this->_data = $this->_getList( $query );
		}

		return $this->_data;
	}

    function delete() {
		JRequest::checkToken() or jexit( 'Invalid Token' );

        global $mainframe;
		$db		=& JFactory::getDBO();
		$cid	= JRequest::getVar( 'cid', array(), '', 'array' );

		JArrayHelper::toInteger($cid);
		$msg = '';

        for ($i=0, $n=count($cid); $i < $n; $i++)
		{
			$projector =& JTable::getInstance('projector', 'Table');
            $query = "DELETE FROM #__contentreactor_slides WHERE `projector_id` = '".$cid[$i] ."'";
            $db->setQuery($query);
            $db->query();
			if (!$projector->delete( $cid[$i] ))
			{
				$msg .= $projector->getError();
                return false;
			}
		}
        return true;


    }
}