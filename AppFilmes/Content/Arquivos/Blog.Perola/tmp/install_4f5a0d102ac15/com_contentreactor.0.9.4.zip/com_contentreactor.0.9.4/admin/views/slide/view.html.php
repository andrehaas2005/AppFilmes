<?php
/**
 * @package     Tyliai
 * @subpackage  Content Reactor
 * @link        http://www.tyliai.eu
 * @author      edast
 * @license		GNU/GPL
 * @
 */

// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

jimport( 'joomla.application.component.view' );

class ContentreactorsViewSlide extends JView
{
	function display($tpl = null)
	{
        $slide		= & $this->get( 'Data');
        $isNew		= ($slide->id < 1);
        $document =& JFactory::getDocument();
        $document->addStyleSheet('components/com_contentreactor/css/style.css');
        
		$text = $isNew ? JText::_( 'New' ) : JText::_( 'Edit' );
		JToolBarHelper::title(   JText::_( 'Slide' ).': <small><small>[ ' . $text.' ]</small></small>', 'contentreactor' );
        JToolBarHelper::save();
        JToolBarHelper::apply();
        if ($isNew) {
            JToolBarHelper::cancel();
        } else {
            JToolBarHelper::cancel( 'cancel', JTEXT::_( 'Close') );
        }
        JToolBarHelper::spacer();


        if (JRequest::getVar( 'task' ) == 'addSlide')
            $slide->projector_id = JRequest::getVar( 'id' );
		$this->assignRef('slide',		$slide);

        $effect_list = $this->get('SelectList');
        $this->assignRef('eff_list', $effect_list);

		parent::display($tpl);
	}
}