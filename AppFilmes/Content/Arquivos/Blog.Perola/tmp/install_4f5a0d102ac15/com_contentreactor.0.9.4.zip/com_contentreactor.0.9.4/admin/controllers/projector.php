<?php
/**
 *
 *
 * @package     Tyliai
 * @subpackage  Content Reactor
 * @link        http://www.tyliai.eu
 * @author      edast
 * @license		GNU/GPL
 * @
 */

// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );
jimport('joomla.filesystem.file');

class ContentreactorsControllerProjector extends ContentreactorsController
{
    /**
     * constructor (registers additional tasks to methods)
     * @return void
     */
    function __construct()
    {
        parent::__construct();

        // Register Extra tasks
        $this->registerTask( 'add'  , 	'edit' );
        $this->registerTask( 'removeProjector', 	'remove' );
        $this->registerTask( 'apply', 		'save');
        $this->registerTask( 'unpublish', 	'publish');
    }

    /**
     * display the edit form
     * @return void
     */
    function edit()
    {
        JRequest::setVar( 'view', 'projector' );
        JRequest::setVar( 'layout', 'form'  );
        JRequest::setVar('hidemainmenu', 1);

        parent::display();
    }

    function addSlide() {
        JRequest::setVar( 'view', 'slide' );
        JRequest::setVar( 'layout', 'form'  );
        JRequest::setVar('hidemainmenu', 1);

        parent::display();
    }
    /**
     * save a record (and redirect to main page)
     * @return void
     */
    function save()
    {
        $model = $this->getModel('projector');

        if ($model->store($post)) {
            $msg = JText::_( 'Projector Saved! ' );
        } else {
            $msg = JText::_( 'Error Saving Projector ');
        }

        // Check the table in so it can be edited.... we are done with it anyway
        $link = 'index.php?option=com_contentreactor';
        switch ($this->_task)
        {
            case 'apply':
                $msg = JText::_( 'Changes to Projector Saved' );
                $link = 'index.php?option=com_contentreactor&controller=projector&task=edit&cid[]='. $model->getId() .'';
                break;

            case 'save':
                default:
                    $link = 'index.php?option=com_contentreactor';
                    break;
            }
            $this->setRedirect($link, $msg);
        }

    /**
     * remove record(s)
     * @return void
     */
        function remove()
        {
            JRequest::checkToken() or jexit( 'Invalid Token' );
            $msg_txt = 'Slide';
            switch ($this->_task)
            {
                case 'removeProjector':
                    $model = $this->getModel('contentreactors');
                    $link='index.php?option=com_contentreactor';
                    $msg_txt = 'Projector';
                    break;
                
                case 'remove':
                default:
                    $model = $this->getModel('projector');
                    $link = 'index.php?option=com_contentreactor&controller=projector&task=edit&cid[]='. JRequest::getVar('id') .'';
                    break;
            }
            
            
            if(!$model->delete()) {
                $msg = JText::_( 'Error: One or More '.$msg_txt.'s Could not be Deleted' );
            } else {
                $msg = JText::_( $msg_txt.'(s) Deleted' );
            }

            $this->setRedirect( $link, $msg );
        }

    /**
     * cancel editing a record
     * @return void
     */
        function cancel()
        {
            $msg = JText::_( 'Operation Cancelled' );
            $this->setRedirect( 'index.php?option=com_contentreactor', $msg );
        }

        function publish()
        {
            global $mainframe;

            JRequest::checkToken() or jexit( 'Invalid Token' );

            $db 	=& JFactory::getDBO();
            $user 	=& JFactory::getUser();

            $cid		= JRequest::getVar( 'cid', array(), '', 'array' );
            $publish	= ( $this->getTask() == 'publish' ? 1 : 0 );

            JArrayHelper::toInteger($cid);

            if (count( $cid ) < 1)
            {
                $action = $publish ? 'publish' : 'unpublish';
                JError::raiseError(500, JText::_( 'Select an item to' .$action, true ) );
            }

            $cids = implode( ',', $cid );
            $query = 'UPDATE #__contentreactor_slides'
            . ' SET published = ' . (int) $publish
            . ' WHERE id IN ( '. $cids .' )'
            ;
            $db->setQuery( $query );
            if (!$db->query())
            {
                JError::raiseError(500, $db->getErrorMsg() );
            }

            $mainframe->redirect( 'index.php?option=com_contentreactor&controller=projector&task=edit&cid[]='.JRequest::getVar('id') );
        }

     }