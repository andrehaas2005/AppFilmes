/* 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
(function($) {
$.fn.cycle.transitions.bounceUp = function($cont, $slides, opts) {
    var $el = $($slides[0]);
    var w = $el.width();
    var h = $el.height();
    var startX = 0 - h - 10;
    opts.sync      = 0;
    opts.easeOut   = 'easeIn';
    opts.easeIn    = 'easeOut';
    opts.cssBefore = { top: startX, left: 0, display: 'block' };
    opts.animIn    = { top: 0 };
    opts.animOut   = { top: -h };
    opts.cssAfter  = { display: 'none' };
    opts.speedIn   = 500;
    opts.speedOut  = 500;

};

})(jQuery);