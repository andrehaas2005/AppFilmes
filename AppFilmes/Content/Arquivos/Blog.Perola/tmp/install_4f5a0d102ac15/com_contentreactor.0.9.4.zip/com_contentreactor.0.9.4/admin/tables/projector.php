<?php
/**
 * @package     Tyliai
 * @subpackage  Content Reactor
 * @link        http://www.tyliai.eu
 * @author      edast
 * @license		GNU/GPL
 * @
 */

// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

class TableProjector extends JTable
{
	/**
	 * Primary Key
	 *
	 * @var int
	 */
	var $id = null;

	/**
	 * @var string
	 */
	var $name = null;

	/**
	 * @var string
	 */
	var $pic_css = null;
	/**
	 * @var string
	 */
	var $info_css = null;
	/**
	 * @var string
	 */
	var $pic_effect = null;
	/**
	 * @var string
	 */
	var $info_effect = null;
	/**
	 * @var string
	 */
	var $info_ease_in = null;
	/**
	 * @var string
	 */
	var $info_ease_out = null;
	/**
	 * @var string
	 */
	var $pic_ease_in = null;
	/**
	 * @var string
	 */
	var $pic_ease_out = null;
	/**
	 * @var int
	 */
	var $width = null;
	/**
	 * @var int
	 */
	var $height = null;
	/**
	 * @var int
	 */
	var $pic_width = null;
	/**
	 * @var int
	 */
	var $pic_height = null;
    /**
     * @var int
     */
    var $slide_interval = 1000;

	/**
	 * Constructor
	 *
	 * @param object Database connector object
	 */
	function TableProjector(& $db) {
		parent::__construct('#__contentreactor_projectors', 'id', $db);
	}
}