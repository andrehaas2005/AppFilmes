-- --------------------------------------------------------

--
-- Table structure for table `#__contentreactor`
--

CREATE TABLE IF NOT EXISTS `#__contentreactor` (
  `default_weight` int(10) unsigned NOT NULL,
  `default_hight` int(10) unsigned default NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `#__contentreactor`
--


-- --------------------------------------------------------

--
-- Table structure for table `#__contentreactor_effects`
--

CREATE TABLE IF NOT EXISTS `#__contentreactor_effects` (
  `id` int(11) NOT NULL auto_increment,
  `parent` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `value` text NOT NULL,
  `params` text NOT NULL,
  `description` text NOT NULL,
  KEY `id` (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 ;

--
-- Dumping data for table `#__contentreactor_effects`
--

INSERT INTO `#__contentreactor_effects` (`id`, `parent`, `name`, `value`, `params`, `description`) VALUES
(1, 'pic_effect', 'blindX', 'blindX', '', ''),
(2, 'pic_effect', 'blindY', 'blindY', '', ''),
(3, 'pic_effect', 'blindZ', 'blindZ', '', ''),
(4, 'pic_effect', 'cover', 'cover', '', ''),
(5, 'pic_effect', 'curtainX', 'curtainX', '', ''),
(6, 'pic_effect', 'curtainY', 'curtainY', '', ''),
(7, 'pic_effect', 'fade', 'fade', '', ''),
(8, 'pic_effect', 'fadeZoom', 'fadeZoom', '', ''),
(9, 'pic_effect', 'growX', 'growX', '', ''),
(10, 'pic_effect', 'growY', 'growY', '', ''),
(11, 'pic_effect', 'scrollUp', 'scrollUp', '', ''),
(12, 'pic_effect', 'scrollDown', 'scrollDown', '', ''),
(13, 'pic_effect', 'scrollLeft', 'scrollLeft', '', ''),
(14, 'pic_effect', 'scrollRight', 'scrollRight', '', ''),
(15, 'pic_effect', 'shuffle', 'shuffle', '', ''),
(16, 'pic_effect', 'slideX', 'slideX', '', ''),
(17, 'pic_effect', 'slideY', 'slideY', '', ''),
(18, 'pic_effect', 'toss', 'toss', '', ''),
(19, 'pic_effect', 'turnUp', 'turnUp', '', ''),
(20, 'pic_effect', 'turnDown', 'turnDown', '', ''),
(21, 'pic_effect', 'turnLeft', 'turnLeft', '', ''),
(22, 'pic_effect', 'turnRight', 'turnRight', '', ''),
(23, 'pic_effect', 'uncover', 'uncover', '', ''),
(24, 'pic_effect', 'wipe', 'wipe', '', ''),
(25, 'pic_effect', 'zoom', 'zoom', '', ''),
(26, 'pic_effect', 'bounceUp', 'bounceUp', '', ''),
(27, 'easing', 'default', '', '', ''),
(28, 'easing', 'def', 'def', '', ''),
(29, 'easing', 'easeInQuad', 'easeInQuad', '', ''),
(30, 'easing', 'easeOutQuad', 'easeOutQuad', '', ''),
(31, 'easing', 'easeInOutQuad', 'easeInOutQuad', '', ''),
(32, 'easing', 'easeInCubic', 'easeInCubic', '', ''),
(33, 'easing', 'easeOutCubic', 'easeOutCubic', '', ''),
(34, 'easing', 'easeInOutCubic', 'easeInOutCubic', '', ''),
(35, 'easing', 'easeInQuart', 'easeInQuart', '', ''),
(36, 'easing', 'easeOutQuart', 'easeOutQuart', '', ''),
(37, 'easing', 'easeInOutQuart', 'easeInOutQuart', '', ''),
(38, 'easing', 'easeInQuint', 'easeInQuint', '', ''),
(39, 'easing', 'easeOutQuint', 'easeOutQuint', '', ''),
(40, 'easing', 'easeInOutQuint', 'easeInOutQuint', '', ''),
(41, 'easing', 'easeInSine', 'easeInSine', '', ''),
(42, 'easing', 'easeOutSine', 'easeOutSine', '', ''),
(43, 'easing', 'easeInOutSine', 'easeInOutSine', '', ''),
(44, 'easing', 'easeInExpo', 'easeInExpo', '', ''),
(45, 'easing', 'easeOutExpo', 'easeOutExpo', '', ''),
(46, 'easing', 'easeInOutExpo', 'easeInOutExpo', '', ''),
(47, 'easing', 'easeInCirc', 'easeInCirc', '', ''),
(48, 'easing', 'easeOutCirc', 'easeOutCirc', '', ''),
(49, 'easing', 'easeInOutCirc', 'easeInOutCirc', '', ''),
(50, 'easing', 'easeInElastic', 'easeInElastic', '', ''),
(51, 'easing', 'easeOutElastic', 'easeOutElastic', '', ''),
(52, 'easing', 'easeInOutElastic', 'easeInOutElastic', '', ''),
(53, 'easing', 'easeInBack', 'easeInBack', '', ''),
(54, 'easing', 'easeOutBack', 'easeOutBack', '', ''),
(55, 'easing', 'easeInOutBack', 'easeInOutBack', '', ''),
(56, 'easing', 'easeInBounce', 'easeInBounce', '', ''),
(57, 'easing', 'easeOutBounce', 'easeOutBounce', '', ''),
(58, 'easing', 'easeInOutBounce', 'easeInOutBounce', '', ''),
(59, 'easing', 'jswing', 'jswing', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `#__contentreactor_projectors`
--

CREATE TABLE IF NOT EXISTS `#__contentreactor_projectors` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `name` varchar(255) NOT NULL,
  `template` int(10) unsigned NOT NULL,
  `width` int(11) NOT NULL,
  `height` int(11) NOT NULL,
  `pic_width` int(11) NOT NULL,
  `pic_height` int(11) NOT NULL,
  `gen_style` text NOT NULL,
  `slide_interval` int(11) NOT NULL,
  `pic_effect` varchar(255) NOT NULL,
  `info_effect` varchar(255) NOT NULL,
  `pic_ease_in` varchar(255) NOT NULL,
  `pic_ease_out` varchar(255) NOT NULL,
  `info_ease_in` varchar(255) NOT NULL,
  `info_ease_out` varchar(255) NOT NULL,
  `info_css` text NOT NULL,
  `pic_css` text NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 ;

--
-- Dumping data for table `#__contentreactor_projectors`
--

INSERT INTO `#__contentreactor_projectors` (`id`, `name`, `template`, `width`, `height`, `pic_width`, `pic_height`, `gen_style`, `slide_interval`, `pic_effect`, `info_effect`, `pic_ease_in`, `pic_ease_out`, `info_ease_in`, `info_ease_out`, `info_css`, `pic_css`) VALUES
(1, 'Demo Projector', 0, 740, 440, 740, 300, '', 6000, 'scrollUp', 'bounceUp', 'easeInOutCubic', 'easeInOutCubic', 'easeInOutCubic', 'easeInOutCubic', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `#__contentreactor_slides`
--

CREATE TABLE IF NOT EXISTS `#__contentreactor_slides` (
  `id` int(11) NOT NULL auto_increment,
  `projector_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `published` tinyint(1) default '1',
  `info` text NOT NULL,
  `picture` varchar(255) NOT NULL,
  `info_css` text NOT NULL,
  `pic_css` text NOT NULL,
  `pic_effect` varchar(255) NOT NULL,
  `info_effect` varchar(255) NOT NULL,
  `pic_ease_in` varchar(255) NOT NULL,
  `pic_ease_out` varchar(255) NOT NULL,
  `info_ease_in` varchar(255) NOT NULL,
  `info_ease_out` varchar(255) NOT NULL,
  `interval` int(11) NOT NULL,
  `order` int(11) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 ;

--
-- Dumping data for table `#__contentreactor_slides`
--

INSERT INTO `#__contentreactor_slides` (`id`, `projector_id`, `name`, `published`, `info`, `picture`, `info_css`, `pic_css`, `pic_effect`, `info_effect`, `pic_ease_in`, `pic_ease_out`, `info_ease_in`, `info_ease_out`, `interval`, `order`) VALUES
(1, 1, 'Demo Slide No. 1', 1, '<div class="demoblock"> <p>Demo block 1<br /><span class="bold">Text of Demo block 1</span></p> <p>Demo Block 2:<br /><span class="bold">Text of Demo Block 2</span></p> </div> <div class="dsc"> <p class="slideTitle">The Title of Demo Slide No. 1</p><p>This slide represents, how user can add any number of blocks (divs) to position the content the way desired. E.g. in this slide we have three blocks for different kinds of content. The layout is tableles, styled with css.</p> </div> <div class="nav"> <a class="rm usc" href="http://www.tyliai.eu" target="_blank" title="Read more">Read more</a> <a class="ls" href="http://www.tyliai.eu" target="_blank" title="Launch site">Launch site</a> </div>', '/components/com_contentreactor/slides/demo_slide_1.jpg', '', '', '', '', '', '', '', '', 1000, 1),
(2, 1, 'Demo Slide No. 2', 1, '<div class="demoblock"> <p>Demo block 3<br /><span class="bold">Text of Demo block 3</span></p> <p>Demo Block 4:<br /><span class="bold">Text of Demo Block 4</span></p> </div> <div class="dsc"> <p class="slideTitle">The Title of Demo Slide No. 2</p><p>This slide only has the "Read more" link and no "Launch site" link.</p> </div> <div class="nav"> <a class="rm" href="http://www.tyliai.eu" target="_blank" title="Read more">Read more</a> </div>', '/components/com_contentreactor/slides/demo_slide_2.jpg', '', '', '', '', '', '', '', '', 1000, 2),
(3, 1, 'Demo Slide No. 3', 1, '<div class="demoblock"> <p>Demo block 5<br /><span class="bold">Text of Demo block 5</span></p> <p>Demo Block 6:<br /><span class="bold">Text of Demo Block 6</span></p> </div> <div class="dsc"> <p class="slideTitle">The Title of Demo Slide No. 3</p><p>This slide only has the "Launch site" link and no "Read more" link.</p> </div> <div class="nav"><a class="ls" href="http://www.tyliai.eu" target="_blank" title="Launch site">Launch site</a> </div>', '/components/com_contentreactor/slides/demo_slide_3.jpg', '', '', '', '', '', '', '', '', 1000, 3);
