<?php
/**
 * @package     Tyliai
 * @subpackage  Content Reactor
 * @link        http://www.tyliai.eu
 * @author      edast
 * @license		GNU/GPL
 * @
 */

// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

jimport( 'joomla.application.component.view' );

class ContentreactorsViewProjector extends JView
{

    function display($tpl = null)
	{
        global $mainframe;
        JHTML::_('behavior.mootools');

        $document =& JFactory::getDocument();

        JHTML::_('behavior.mootools');

        $document->addScript('../components/com_contentreactor/js/jquery-1.3.1.min.js');
        $document->addScript('../components/com_contentreactor/js/jquery.lightbox.js');
        $document->addScriptDeclaration("jQuery.noConflict();");
        $document->addScriptDeclaration("
                    (function($) {
                        $(document).ready(function(){
                            $('a.lightbox').lightbox();
                        });
                    })(jQuery);");
        $document->addStyleSheet('../components/com_contentreactor/css/lightbox.css');
        $document->addStyleSheet('components/com_contentreactor/css/style.css');

        $projector		=& $this->get('Data');
		$isNew		= ($projector->id < 1);

        $slides =& $this->get('Slides');

		$text = $isNew ? JText::_( 'New' ) : JText::_( 'Edit' );
		JToolBarHelper::title(   JText::_( 'Content Reactor projector manager' ).': <small><small>[ ' . $text.' ]</small></small>', 'contentreactor' );
		JToolBarHelper::save();
		JToolBarHelper::apply();
        JToolBarHelper::spacer();
        JToolBarHelper::divider();
		JToolBarHelper::deleteList(JText::_('Are you sure?') );
        if (!$isNew) {
            JToolBarHelper::editListX();
            JToolBarHelper::addNewX("addSlide", JText::_('add slide'));
//            JToolBarHelper::preview("../index.php?option=com_contentreactor&id=".$projector->id."&tmpl=component", false);
        }

        if ($isNew)  {
			JToolBarHelper::cancel();
		} else {
			// for existing items the button is renamed `close`
			JToolBarHelper::cancel( 'cancel', 'Close' );
		}
        $effect_list = $this->get('SelectList');
        $easing_list = $this->get('SelectListEasing');

        $this->assignRef('eff_list', $effect_list);
		$this->assignRef('projector', $projector);
        $this->assignRef('slides', $slides);
        $this->assignRef('easing_list', $easing_list);

		parent::display($tpl);
	}
}