<?php
/**
 * @package     Tyliai
 * @subpackage  Content Reactor
 * @link        http://www.tyliai.eu
 * @author      edast
 * @license		GNU/GPL
 * @
 */

// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die();

jimport( 'joomla.application.component.model' );

class ContentreactorModelContentreactor extends JModel
{
    function getProjector()
    {
        $db =& JFactory::getDBO();

        $query = 'SELECT * FROM #__contentreactor_projectors WHERE id = 2';
        $db->setQuery( $query );
        $projector = $db->loadResult();

        return $projector;
    }

	function setId($id)
	{
		$this->_id		= $id;
		$this->_data	= null;
	}

    function getData()
    {

		if (empty( $this->_data )) {
			$query = ' SELECT * FROM #__contentreactor_projectors '.
					'  WHERE id = '. $this->$_id;
			$this->_db->setQuery( $query );
			$this->_data = $this->_db->loadObject();
		}
		if (!$this->_data) {
			$this->_data = new stdClass();
			$this->_data->id = 0;
		}
		return $this->_data;

     }

    function getCss() {
        return "";
    }
}
