<?php
/**
 * @package     Tyliai
 * @subpackage  Content Reactor
 * @link        http://www.tyliai.eu
 * @author      edast
 * @license		GNU/GPL
 * @
 */
// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

class ContentreactorsControllerSlide extends ContentreactorsController
{
	/**
	 * constructor (registers additional tasks to methods)
	 * @return void
	 */
	function __construct()
	{
		parent::__construct();

		// Register Extra tasks
        $this->registerTask( 'apply', 		'save');
		$this->registerTask( 'add'  , 	'edit' );
	}

	/**
	 * display the edit form
	 * @return void
	 */
	function edit()
	{
		JRequest::setVar( 'view', 'slide' );
		JRequest::setVar( 'layout', 'form'  );
		JRequest::setVar('hidemainmenu', 1);

		parent::display();
	}

	/**
	 * save a record (and redirect to main page)
	 * @return void
	 */
	function save()
	{
		$model = $this->getModel('slide');

		if ($model->store($post)) {
			$msg = JText::_( 'Projector Saved!' );
		} else {
			$msg = JText::_( 'Error Saving Projector' );
		}

		$link = 'index.php?option=com_contentreactor';
		switch ($this->_task)
		{
			case 'apply':
				$msg = JText::_( 'Changes to Slide Saved' );
				$link = 'index.php?option=com_contentreactor&controller=slide&task=edit&cid[]='. $model->getId() .'';
				break;

			case 'save':
			default:
				$link = 'index.php?option=com_contentreactor&controller=projector&task=edit&cid[]='.JRequest::getVar('projector_id');
				break;
		}
        $this->setRedirect( $link, $msg );
	}

	/**
	 * remove record(s)
	 * @return void
	 */
	function remove()
	{
		$model = $this->getModel('projector');
		if(!$model->delete()) {
			$msg = JText::_( 'Error: One or More Slides Could not be Deleted' );
		} else {
			$msg = JText::_( 'Slide(s) Deleted' );
		}

        $this->setRedirect( 'index.php?option=com_contentreactor&controller=projector&task=edit&cid[]='.JRequest::getVar('projector_id'), $msg );
	}

	/**
	 * cancel editing a record
	 * @return void
	 */
	function cancel()
	{
		$msg = JText::_( 'Operation Cancelled' );
        $this->setRedirect( 'index.php?option=com_contentreactor&controller=projector&task=edit&cid[]='.JRequest::getVar('projector_id'), $msg );
	}
}