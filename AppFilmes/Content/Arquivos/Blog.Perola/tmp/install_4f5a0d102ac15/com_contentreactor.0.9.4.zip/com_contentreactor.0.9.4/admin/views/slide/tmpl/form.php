<?php
/**
 * @package     Tyliai
 * @subpackage  Content Reactor
 * @link        http://www.tyliai.eu
 * @author      edast
 * @license		GNU/GPL
 * @
 */
defined('_JEXEC') or die('Restricted access'); ?>


<form action="index.php" method="post" name="adminForm" id="adminForm" enctype="multipart/form-data">
    <div class="col100">
        <fieldset class="adminform">
            <legend><?php echo JText::_( 'Details' ); ?></legend>

            <table class="admintable">
                <tr>
                    <td width="100" align="right" class="key">
                        <label for="name">
                            <?php echo JText::_( 'Name' ); ?>:
                        </label>
                    </td>
                    <td>
                        <input class="text_area" type="text" name="name" id="name" size="32" maxlength="250" value="<?php echo $this->slide->name;?>" />
                    </td>
                </tr>
                <tr>
                    <td width="100" align="right" class="key">
                        <label for="order">
                            <?php echo JText::_( 'Order number' ); ?>:
                        </label>
                    </td>
                    <td>
                        <input class="text_area" type="text" name="order" id="order" size="32" maxlength="250" value="<?php echo $this->slide->order;?>" />
                    </td>
                </tr>
                <tr>
                    <td width="120" class="key">
                        <?php echo JText::_( 'Publish' ); ?>:
                    </td>
                    <td>
                        <?php echo JHTML::_( 'select.booleanlist',  'published', 'class="inputbox"', $this->slide->published ); ?>
                    </td>
                </tr>
                <tr>
                    <td width="100" align="right" class="key">
                        <label for="picture">
                            <?php echo JText::_( 'Image URL' ); ?>:
                        </label>
                    </td>
                    <td>
                        <input class="text_area" type="text" name="picture" id="picture" size="42" maxlength="250" value="<?php echo $this->slide->picture;?>" />
                    </td>
                </tr>
                <tr>
                    <td width="100" align="right" class="key">
                        <label for="fileupload">
                            <?php echo JText::_( 'or upload it' ); ?>:
                        </label>
                    </td>
                    <td>
                        <input class="text_area" size="32" maxlength="250" type="file" id="fileupload" name="fileupload" />
                    </td>
                </tr>
                <tr>
                    <td width="100" align="right" class="key">
                        <label for="info">
                            <?php echo JText::_( 'Text area' ); ?>:
                        </label>
                    </td>
                    <td>
                        <!-- <textarea id="info" name="info" cols="60" rows="10"><?php// echo $this->slide->info?> </textarea>-->
                        <?php
                            $editor =& JFactory::getEditor();
                            echo $editor->display('info', $this->slide->info, '100%', '400', '60', '20', false);
                        ?>
                    </td>

                </tr>
            </table>
        </fieldset>
    </div>

    <div class="clr"></div>

    <input type="hidden" name="option" value="com_contentreactor" />
    <input type="hidden" name="id" value="<?php echo $this->slide->id; ?>" />
    <input type="hidden" name="projector_id" value="<?php echo $this->slide->projector_id; ?>" />
    <input type="hidden" name="task" value="" />
    <input type="hidden" name="controller" value="slide" />
    <?php echo JHTML::_( 'form.token' ); ?>
</form>
