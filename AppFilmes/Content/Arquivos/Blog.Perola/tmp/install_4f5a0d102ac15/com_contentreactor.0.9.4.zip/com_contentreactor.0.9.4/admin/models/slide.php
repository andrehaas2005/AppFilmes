<?php
/**
 * @package     Tyliai
 * @subpackage  Content Reactor
 * @link        http://www.tyliai.eu
 * @author      edast
 * @license		GNU/GPL
 * @
 */

// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

jimport('joomla.application.component.model');

class ContentreactorsModelSlide extends JModel
{

    var $_silde_id;
    /**
     * Constructor that retrieves the ID from the request
     *
     * @access	public
     * @return	void
     */
    function __construct()
    {
        parent::__construct();

        $array = JRequest::getVar('cid',  0, '', 'array');
        $this->setId((int)$array[0]);
    }

    function setId($id)
    {
        // Set id and wipe data
        $this->_id		= $id;
        $this->_data	= null;
    }

    function &getData()
    {
        // Load the data
        if (empty( $this->_data )) {
            $query = ' SELECT * FROM #__contentreactor_slides '.
                    '  WHERE id = '.$this->_id.' ORDER BY `order`';
            $this->_db->setQuery( $query );
            $this->_data = $this->_db->loadObject();
        }
        if (!$this->_data) {
            $this->_data = new stdClass();
            $this->_data->id = 0;
        }
        return $this->_data;
    }


    /**
     * Method to store a record
     *
     * @access	public
     * @return	boolean	True on success
     */
    function store()
    {
        $row =& $this->getTable();

        $data = JRequest::get( 'post', 4 );

        $file = JRequest::getVar('fileupload', null, 'files', 'array');
        if ($file['name']) {
            jimport('joomla.filesystem.file');
            $filename = JFile::makeSafe($file['name']);
            $src = $file['tmp_name'];
            $dest = JPATH_SITE . DS . "images" . DS . $filename;

            //First check if the file has the right extension, we need jpg only
            if ( strtolower(JFile::getExt($filename) ) == 'jpg' || strtolower(JFile::getExt($filename) ) == 'png' || strtolower(JFile::getExt($filename) ) == 'gif') {
                if ( JFile::upload($src, $dest) ) {
                    //Redirect to a page of your choice
                    $data['picture'] =  JURI::root()."images/".$filename;
               } else {
                    $this->setError("could not upload image");
                    return false;
                    //Redirect and throw an error message
                }
            } else {
                $this->setError("file can be jpg, png or gif only");
                return false;
                //Redirect and notify user file is not right extension
            }

        }

        if (!$row->bind($data)) {
            $this->setError($this->_db->getErrorMsg());
            return false;
        }

        if (!$row->check()) {
            $this->setError($this->_db->getErrorMsg());
            return false;
        }

        // Store the web link table to the database
        if (!$row->store()) {
            $this->setError( $row->getErrorMsg() );
            return false;
        }
        $this->_silde_id = $row->id;
        return true;
    }

    /**
     * Method to delete record(s)
     *
     * @access	public
     * @return	boolean	True on success
     */
    function delete()
    {
        $cids = JRequest::getVar( 'cid', array(0), 'post', 'array' );

        $row =& $this->getTable();

        if (count( $cids )) {
            foreach($cids as $cid) {
                if (!$row->delete( $cid )) {
                    $this->setError( $row->getErrorMsg() );
                    return false;
                }
            }
        }
        return true;
    }

    function getSelectList() {
        $parent =  'pic_effect';
        $list_options = array();
        $query = "SELECT `value` AS `value`, `name` AS `text` FROM #__contentreactor_effects WHERE `parent` = '".$parent."'";

        $list_options = $this->_getList($query);
        return $list_options;
    }

    function getId() {
        return $this->_silde_id;
    }
}