<?php
/**
 * @package     Tyliai
 * @subpackage  Content Reactor
 * @link        http://www.tyliai.eu
 * @author      edast
 * @license		GNU/GPL
 * @
 */

// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

jimport( 'joomla.application.component.view' );

class ContentreactorsViewContentreactors extends JView
{
    function display($tpl = null)
    {

        global $mainframe;
        JHTML::_('behavior.mootools');

        $document =& JFactory::getDocument();

        JHTML::_('behavior.mootools');

        $document->addScript('../components/com_contentreactor/js/jquery-1.3.1.min.js');
        $document->addScript('../components/com_contentreactor/js/greybox.js');
        $document->addScriptDeclaration("jQuery.noConflict();");
        $document->addStyleSheet('../components/com_contentreactor/css/greybox.css');
        $document->addStyleSheet('components/com_contentreactor/css/style.css');

        JToolBarHelper::title(   JText::_( 'Projector Manager' ), 'contentreactor' );
        JToolBarHelper::deleteList(JText::_('Are you sure?'), 'removeProjector');
        JToolBarHelper::editListX();
        JToolBarHelper::addNewX('add', 'Add projector');
        //JToolBarHelper::help("help");
        //JToolBarHelper::preferences();


        // Get data from the model
        $items		= & $this->get( 'Data');

        $this->assignRef('items',		$items);

        parent::display($tpl);
    }
}