<?php
/**
 * @package     Tyliai
 * @subpackage  Content Reactor
 * @link        http://www.tyliai.eu
 * @author      edast
 * @license		GNU/GPL
 * @
 */
defined('_JEXEC') or die( 'Restricted access' );
jimport( 'joomla.application.component.view');

class ContentreactorViewContentreactor extends JView
{
    function display($tpl = null)
    {
        global $mainframe;

        $db 	  =& JFactory::getDBO();
        $document =& JFactory::getDocument();
        $pathway  =& $mainframe->getPathway();

        $document =& JFactory::getDocument();
        $document->addScript(JURI::base().'/components/com_contentreactor/js/jquery-1.3.1.min.js');
        $document->addScript(JURI::base().'/components/com_contentreactor/js/jquery-ui-min.js');
        $document->addScript(JURI::base().'/components/com_contentreactor/js/jquery.cycle.all.min.js');
        $document->addScript(JURI::base().'/components/com_contentreactor/js/jquery.easing.js');
        $document->addScript(JURI::base().'/components/com_contentreactor/js/jquery.easing.compatibility.js');
        $document->addScript(JURI::base().'/components/com_contentreactor/js/jquery.timers.js');
        $document->addScript(JURI::base().'/components/com_contentreactor/js/tyliai.cycle.effects.js');
        $document->addStyleSheet(JURI::base().'/components/com_contentreactor/css/style.css');
        $projector_id = JRequest::getVar( 'id', 0, '', 'int' );

        $projector =& JTable::getInstance('projector', 'Table');
        $projector->load( $projector_id );

        $document->addStyleDeclaration("#tyliai_cr_visual{width:".$projector->pic_width."px;height:".$projector->pic_height."px;}
            #tyliai_cr_visual div {width: ".$projector->pic_width."px;height: ".$projector->pic_height."px;}
            #info{width:".$projector->width."px;height: ".($projector->height - $projector->pic_height)."px;}
            .info_inner {height:".($projector->height - $projector->pic_height)."px;width: ".$projector->width."px;}", "text/css");

        $query = "SELECT * from #__contentreactor_slides WHERE projector_id = ".$projector_id. " AND  `published` =1 ORDER BY `order`, `id` ";
        $db->setQuery( $query );
        $slides = $db->loadObjectList();
//        $style = $this->getCss($projector);
//        $document->addStyleDeclaration($style, "text/css");
        $this->assignRef( 'projector',	$projector );
        //        $this->assignRef( 'style',	$style );
        $this->assignRef( 'slides',	$slides );

        parent::display($tpl);
    }

//    function getCss($projector) {
//        $css_str = file_get_contents(JPATH_COMPONENT.DS.'css'.DS.'style.css');
//
//        $css_str = str_replace('{PIC_WIDTH}', $projector->pic_width, $css_str);
//        $css_str = str_replace('{PIC_HEIGHT}', $projector->pic_height, $css_str);
//        $css_str = str_replace('{INFO_WIDTH}', $projector->width, $css_str);
//        $css_str = str_replace('{INFO_HEIGHT}', ($projector->height - $projector->pic_height), $css_str);
//        return $css_str;
//    }
}
?>
