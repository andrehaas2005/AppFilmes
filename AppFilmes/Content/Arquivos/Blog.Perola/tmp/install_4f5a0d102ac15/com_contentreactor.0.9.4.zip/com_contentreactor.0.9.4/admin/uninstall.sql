DROP TABLE IF EXISTS `#__contentreactor`;
DROP TABLE IF EXISTS `#__contentreactor_effects`;
DROP TABLE IF EXISTS `#__contentreactor_projectors`;
DROP TABLE IF EXISTS `#__contentreactor_slides`;
